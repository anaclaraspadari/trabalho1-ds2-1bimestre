class CD{
    constructor(id, titulo, artista, datalancamento, faixas){
        this.id=id,
        this.titulo=titulo,
        this.artista=artista,
        this.datalancamento=datalancamento,
        this.faixas=faixas
    }
};

module.exports= CD;

